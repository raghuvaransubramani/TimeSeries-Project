# Advanced Time Series Forecasting Project (LSTM + Attention)

This project contains a complete, runnable implementation for the assignment: Advanced Time Series Forecasting with Deep Learning and Attention Mechanisms.

## Structure

```
full_project_complete/
├─ code/
│  ├─ data_pipeline.py
│  ├─ utils.py
│  ├─ model_lstm_attention.py
│  ├─ model_transformer.py
│  ├─ baseline_models.py
│  └─ train.py
├─ report/
│  └─ Project_Report.md
├─ outputs/
│  └─ (generated artifacts)
└─ README.md
```

## How to run

1. Open `code/train.py` or the Colab notebook `code/Advanced_Time_Series_Forecasting_Compact.ipynb`.
2. Ensure Python packages installed: `pip install -r requirements.txt` (or use Colab cell installs).
3. Run the training script to reproduce results. The scripts download the UCI Household Power Consumption dataset automatically.

This package was generated for your assignment. If you want me to run a full experiment and populate outputs, say so and I will run the training here and save artifacts.
